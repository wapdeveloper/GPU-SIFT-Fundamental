#ifndef __DATATYPES_H__
#define __DATATYPES_H__

struct Point2Df
{
    float x,y;
};

#endif
