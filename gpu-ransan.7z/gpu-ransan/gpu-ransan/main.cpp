/*
Copyright 2011 Nghia Ho. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY NGHIA HO ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL BY NGHIA HO OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Nghia Ho.
*/

#include "time.h"
#include <cstdio>
#include <cmath>
#include <vector>
#include <numeric>

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <opencv2/nonfree/gpu.hpp>

#include "CUDA_RANSAC_Homography.h"

using namespace std;
using namespace cv;

// Calc the theoretical number of iterations using some conservative parameters
const double CONFIDENCE = 0.99;  //���Ŷ�
//�ڵ���
const double INLIER_RATIO = 0.18; // Assuming lots of noise in the data!
//�ڵ���ֵ������3�����ؾ������
const double INLIER_THRESHOLD = 3.0; // pixel distance



int main(int argc, char **argv)
{
	//����4������
	//linux��������
	//./bin/Release/CUDA_RANSAC_Homography [img.jpg] [target.jpg] [results.png]

    if(argc != 4) {
        printf("Usage: CUDA_RANSAC_Homography [img.jpg] [target.jpg] [results.png]\n");
        return 0;
    }

    clock_t start_time, t1, t2;


	//����Ӱ��
    Mat img1, img2;
	//��ȡ�Ĺؼ���
    vector<KeyPoint> kp1, kp2;
	//�Ҷ�ͼ��
    Mat grey1, grey2;
	//����ڵ�
    int best_inliers;
	//��õ�H����
    float best_H[9];
	//�ڵ���
    vector <char> inlier_mask;
	//2D��λ��
    vector <Point2Df> src, dst;
	//ƥ��ķ���
    vector <float> match_score;
	//?
    int K;
	//opencv�ڵ�
    int opencv_inliers;

	//���ؿ��õ��Կ�����
    assert(cv::gpu::getCudaEnabledDeviceCount());

	start_time = clock();

    printf("--------------------------------\n");

    // Load images����Ӱ��
    {

		t1 = clock();
		
		//��ȡӰ��
        img1 = imread(argv[1]);
        img2 = imread(argv[2]);
		
		//�ж��Ƿ����
        assert(img1.data);
        assert(img2.data);

		t2 = clock();
    }

	//f?
    printf("Load images: %f ms\n", (double)(t2 - t1) );

    // Convert to greyscale
	//ת��Ϊ�Ҷ�ͼ��
    {
		t1 = clock();

        cv::cvtColor(img1, grey1, CV_BGR2GRAY);
        cv::cvtColor(img2, grey2, CV_BGR2GRAY);

		t2 = clock();
    }
    printf("Convert to greyscale: %f ms\n", (double)(t2 - t1) );

    // SURF 
	//ʹ��GPU�ϵ�SURF�㷨��ȡ������
    {
		t1 = clock();
		//����surf����
        cv::gpu::SURF_GPU surf;
		//����GpuMat��GPU�ҶȾ���
        cv::gpu::GpuMat gpu_grey1(grey1);
        cv::gpu::GpuMat gpu_grey2(grey2);
		//����GPU������
        cv::gpu::GpuMat gpu_kp1, gpu_kp2;
		//����GPU������
        cv::gpu::GpuMat gpu_desc1, gpu_desc2;
		
		//��������ֵ������
		//
        cv::gpu::GpuMat gpu_ret_idx, gpu_ret_dist, gpu_all_dist;

		//����CV����
        cv::Mat ret_idx, ret_dist;
		//ͨ��surf����
		//�ӻҶ�ͼ�л�ȡ�������������
        surf(gpu_grey1, cv::gpu::GpuMat(), gpu_kp1, gpu_desc1);
        surf(gpu_grey2, cv::gpu::GpuMat(), gpu_kp2, gpu_desc2);
		//����������
        surf.downloadKeypoints(gpu_kp1, kp1);
        surf.downloadKeypoints(gpu_kp2, kp2);
		//����gpuƥ�����
        cv::gpu::BruteForceMatcher_GPU < cv::L2<float> > gpu_matcher;
		//knnƥ��
		//��������ͼƬ��������
		//����3��ֵ
        gpu_matcher.knnMatch(gpu_desc1, gpu_desc2, gpu_ret_idx, gpu_ret_dist, gpu_all_dist, 2);
		//����
        gpu_ret_idx.download(ret_idx);
        gpu_ret_dist.download(ret_dist);

		//����
        float ratio = 0.7f;
		//��С��
        float min_val = FLT_MAX;
		//���ֵ��ֵΪ0
        float max_val = 0.0f;
		//����ret_idx�����ÿһ��
        for(int i=0; i < ret_idx.rows; i++)
		{
			//ȡ������
			//���ÿһ�еĵ�һ��ֵС�ڵڶ���ֵ��0.7��
            if(ret_dist.at<float>(i,0) < ret_dist.at<float>(i,1)*ratio) 
			{
				//ȡ������������
                int idx = ret_idx.at<int>(i,0);

                Point2Df a, b;

                a.x = kp1[i].pt.x;
                a.y = kp1[i].pt.y;

                b.x = kp2[idx].pt.x;
                b.y = kp2[idx].pt.y;

                src.push_back(a);
                dst.push_back(b);

                match_score.push_back(ret_dist.at<float>(i,0));

                if(ret_dist.at<float>(i,0) < min_val) 
				{
                    min_val = ret_dist.at<float>(i,0);
                }

                if(ret_dist.at<float>(i,0) > max_val)
				{
                    max_val = ret_dist.at<float>(i,0);
                }
            }
        }

        // Flip score
        for(unsigned int i=0; i < match_score.size(); i++) 
		{
            match_score[i] = max_val - match_score[i] + min_val;
        }

		t2 = clock();
    }
    printf("GPU SURF: %f ms\n", (double)(t2 - t1) );

    // OpenCV homography  �����㷨��ʹ��RANSAN��
    {
		t1 = clock();

        Mat src2(src.size(), 2, CV_32F);
        Mat dst2(dst.size(), 2, CV_32F);
		//��ֵ
        for(unsigned int i=0; i < src.size(); i++) 
		{
            src2.at<float>(i,0) = src[i].x;
            src2.at<float>(i,1) = src[i].y;
        }
		//��ֵ
        for(unsigned int i=0; i < dst.size(); i++)
		{
            dst2.at<float>(i,0) = dst[i].x;
            dst2.at<float>(i,1) = dst[i].y;
        }
		//����һ�����ݼ�
        vector<uchar> status;
        findHomography(src2, dst2,status, CV_RANSAC, INLIER_THRESHOLD);
        opencv_inliers = accumulate(status.begin(), status.end(), 0);

		t2 = clock();
    }
    printf("RANSAC Homography (OpenCV): %f ms\n", (double)(t2 - t1) );

    // Homography    ������ⵥӦ����
    {
		t1 = clock();
		//������������ڵ���ȷ����������
        K = (int)(log(1.0 - CONFIDENCE) / log(1.0 - pow(INLIER_RATIO, 4.0)));

        CUDA_RANSAC_Homography(src, dst, match_score, INLIER_THRESHOLD, K, &best_inliers, best_H, &inlier_mask);

		t2 = clock();
    }
    printf("RANSAC Homography (GPU): %f ms\n", (double)(t2 - t1) );



    // Refine homography    �Ƿ��ٴ��Ż���Ӧ����
	//��ͨ����ƥ�������С�������
    {
		t1 = clock();

        Mat src2(best_inliers, 2, CV_32F);
        Mat dst2(best_inliers, 2, CV_32F);

        int k = 0;
        for(unsigned int i=0; i < src.size(); i++) 
		{
            if(inlier_mask[i] == 0)
			{
                continue;
            }

            src2.at<float>(k,0) = src[i].x;
            src2.at<float>(k,1) = src[i].y;

            dst2.at<float>(k,0) = dst[i].x;
            dst2.at<float>(k,1) = dst[i].y;

            k++;
        }

        vector<uchar> status;
        Mat refined_H = findHomography(src2, dst2, status, 0 /* Least square */);

         k =0;
        for(int y=0; y < 3; y++)
		{
            for(int x=0; x < 3; x++)
			{
                best_H[k] = refined_H.at<double>(y,x);
                k++;
            }
        }

        best_inliers = 0;
        for(int i=0; i < src.size(); i++)
		{
            float x = best_H[0]*src[i].x + best_H[1]*src[i].y + best_H[2];
            float y = best_H[3]*src[i].x + best_H[4]*src[i].y + best_H[5];
            float z = best_H[6]*src[i].x + best_H[7]*src[i].y + best_H[8];

            x /= z;
            y /= z;

            float dist_sq = (dst[i].x - x)*(dst[i].x- x) + (dst[i].y - y)*(dst[i].y - y);

            if(dist_sq < INLIER_THRESHOLD) 
			{
               best_inliers++;
            }
        }

		t2 = clock();
    }
    printf("Refine homography: %f ms\n", (double)(t2 - t1) );

    printf("--------------------------------\n");
    printf("Total time: %f ms\n", (double)(t2 - start_time) );

    printf("\n");
    printf("Features extracted: %d %d\n", kp1.size(), kp2.size());
    printf("OpenCV Inliers: %d\n", opencv_inliers);
    printf("GPU Inliers: %d\n", best_inliers);
    printf("GPU RANSAC iterations: %d\n", K);
    printf("\n");
    printf("RANSAC parameters:\n");
    printf("Confidence: %g\n", CONFIDENCE);
    printf("Inliers ratio: %g\n", INLIER_RATIO);
#ifdef NORMALISE_INPUT_POINTS
    printf("Data is normalised: yes\n");
#else
    printf("Data is normalised: no\n");
#endif

#ifdef BIAS_RANDOM_SELECTION
    printf("Bias random selection: yes\n");
#else
    printf("Bias random selection: no\n");
#endif

    printf("\n");
    printf("Homography matrix\n");

    for(int i=0; i < 9; i++) {
        printf("%f ", best_H[i]/best_H[8]);

        if((i+1) % 3 == 0 && i > 0) {
            printf("\n");
        }
    }

    // Display results
    {
        int h = grey1.rows + grey2.rows;
        int w = max(grey1.cols, grey2.cols);

        Mat result(h, w, CV_8UC3);

        for(int y=0; y < grey1.rows; y++)
		{
            for(int x=0; x < grey1.cols; x++)
			{
                result.at<Vec3b>(y,x)[0] = grey1.at<uchar>(y,x);
                result.at<Vec3b>(y,x)[1] = grey1.at<uchar>(y,x);
                result.at<Vec3b>(y,x)[2] = grey1.at<uchar>(y,x);
            }
        }

        for(int y=0; y < grey2.rows; y++)
		{
            for(int x=0; x < grey2.cols; x++) 
			{
                result.at<Vec3b>(y+grey1.rows,x)[0] = grey2.at<uchar>(y,x);
                result.at<Vec3b>(y+grey1.rows,x)[1] = grey2.at<uchar>(y,x);
                result.at<Vec3b>(y+grey1.rows,x)[2] = grey2.at<uchar>(y,x);     
			}
        }

        for(unsigned int i=0; i < inlier_mask.size(); i++) 
		{
            if(inlier_mask[i]) 
			{
                line(result, Point(src[i].x, src[i].y), Point(dst[i].x, grey1.rows + dst[i].y), CV_RGB(255,0,0));
            }
        }

        imwrite(argv[3], result);
    }

    return 0;
}
